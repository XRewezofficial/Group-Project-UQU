
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.hci.project;

/*
 ~ @author s447004056 - Abdulaziz
 */

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import com.hci.project.model.Pilgrim;
import com.hci.project.service.Database;
import com.hci.project.ui.PilgrimUI;

public class Main {

    public static void main(String[] args) {
        boolean exit = false;

        while (!exit) {
            String[] roles = {"حاج", "مسؤول حملة (منظم)", "إداري", "إغلاق النظام"};

            int choice = JOptionPane.showOptionDialog(
                null,
                "مرحباً بك في نظام إدارة حجاج الداخل\nالرجاء اختيار نوع الكيان للدخول:",
                "الشاشة الرئيسية - نظام الحج",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,
                roles,
                roles[0]
            );

            switch (choice) {
                case 0:
                    loginAsPilgrim();
                    break;
                    
                case 1:
                    JOptionPane.showMessageDialog(null, 
                        "بوابة مسؤول الحملة (سيتم ربطها بكود الزميل الثاني).", 
                        "تنبيه", JOptionPane.INFORMATION_MESSAGE);
                    break;

                case 2:
                    JOptionPane.showMessageDialog(null, 
                        "بوابة الإدارة (سيتم ربطها بكود الزميل الثالث).", 
                        "تنبيه", JOptionPane.INFORMATION_MESSAGE);
                    break;

                case 3:
                case -1:
                    exit = true;
                    JOptionPane.showMessageDialog(null, "نراكم على خير. تقبل الله طاعتكم.");
                    break;
            }
        }
    }

    // نافذة تسجيل دخول الحاج بالهوية الوطنية والرقم السري
    private static void loginAsPilgrim() {
        JTextField idField = new JTextField();
        JPasswordField passwordField = new JPasswordField();

        Object[] message = {
            "رقم الهوية الوطنية :", idField,
            "الرقم السري:", passwordField
        };

        int option = JOptionPane.showConfirmDialog(
            null, 
            message, 
            "تسجيل دخول الحاج", 
            JOptionPane.OK_CANCEL_OPTION,
            JOptionPane.QUESTION_MESSAGE
        );

        if (option == JOptionPane.OK_OPTION) {
            String inputId = idField.getText();
            String inputPassword = new String(passwordField.getPassword());

            // التأكد من عدم ترك الحقول فارغة
            if (inputId.trim().isEmpty() || inputPassword.trim().isEmpty()) {
                JOptionPane.showMessageDialog(null, "يرجى تعبئة جميع الحقول المطلوب إدخالها!", "تنبيه", JOptionPane.WARNING_MESSAGE);
                return;
            }

            // المطابقة مع قاعدة البيانات المصغرة
            Pilgrim foundPilgrim = Database.authenticatePilgrim(inputId, inputPassword);

            if (foundPilgrim != null) {
                JOptionPane.showMessageDialog(
                    null,
                    "تم تسجيل الدخول بنجاح!\nمرحباً بك: " + foundPilgrim.getName(),
                    "نجاح الدخول",
                    JOptionPane.INFORMATION_MESSAGE
                );
                
                // فتح واجهة الخدمات الخاصة بالحاج
                PilgrimUI.showPilgrimMenu(foundPilgrim);
            } else {
                JOptionPane.showMessageDialog(
                    null,
                    "خطأ: رقم الهوية الوطنية أو الرقم السري غير صحيح!",
                    "خطأ في الدخول",
                    JOptionPane.ERROR_MESSAGE
                );
            }
        }
    }
}