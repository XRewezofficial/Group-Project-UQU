/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.hci.project.service;

/**
 *
 * @author naf
 */

import java.util.ArrayList;
import com.hci.project.model.Pilgrim;

public class Database {
    public static ArrayList<Pilgrim> pilgrimsList = new ArrayList<>();

    // بيانات تجريبية (الهوية, الاسم, الرقم السري, الهاتف, رقم الحافلة, رقم الخيمة)
    static {
        pilgrimsList.add(new Pilgrim("103249", "أحمد محمد", "1234", "0501112223", "B-01", "T-10"));
        pilgrimsList.add(new Pilgrim("107293", "سارة خالد", "5678", "0504445556", "B-02", "T-12"));
        pilgrimsList.add(new Pilgrim("112944", "عبدالله عمر", "1122", "0507778889", "B-01", "T-15"));
    }

    // التحقق من المطابقة بين الهوية وكلمة المرور
    public static Pilgrim authenticatePilgrim(String nationalId, String password) {
        for (Pilgrim p : pilgrimsList) {
            if (p.getNationalId().trim().equals(nationalId.trim()) && 
                p.getPassword().equals(password)) {
                return p; // تم التحقق بنجاح
            }
        }
        return null; // البيانات غير صحيحة
    }
}