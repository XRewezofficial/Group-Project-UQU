/*
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license */
package com.hci.project;
/* ~ @author s447004056 - Abdulaziz */
 import javax.swing.JOptionPane; import javax.swing.JPasswordField; import javax.swing.JTextField; import com.hci.project.model.Organizer; import com.hci.project.service.Database; import com.hci.project.ui.OrganizerUI;
public class OrganizerLogin {
public static void loginAsOrganizer() {

    JTextField idField = new JTextField();
    JPasswordField passwordField = new JPasswordField();


    Object[] message = {
        "رقم المنظم :",
        idField,
        "الرقم السري:",
        passwordField
    };


    int option = JOptionPane.showConfirmDialog(
        null, 
        message, 
        "تسجيل دخول منظم الحملة", 
        JOptionPane.OK_CANCEL_OPTION,
        JOptionPane.QUESTION_MESSAGE
    );


    if (option == JOptionPane.OK_OPTION) {

        String inputId = idField.getText();
        String inputPassword = new String(passwordField.getPassword());


        if (inputId.trim().isEmpty() || inputPassword.trim().isEmpty()) {

            JOptionPane.showMessageDialog(
                null,
                "يرجى تعبئة جميع الحقول المطلوب إدخالها!",
                "تنبيه",
                JOptionPane.WARNING_MESSAGE
            );

            return;
        }


        Organizer foundOrganizer = Database.authenticateOrganizer(inputId, inputPassword);



        if (foundOrganizer != null) {

            JOptionPane.showMessageDialog(
                null,
                "تم تسجيل الدخول بنجاح!\nمرحباً بك: " + foundOrganizer.getName(),
                "نجاح الدخول",
                JOptionPane.INFORMATION_MESSAGE
            );


            OrganizerUI.showOrganizerMenu(foundOrganizer);


        } else {

            JOptionPane.showMessageDialog(
                null,
                "خطأ: رقم المنظم أو الرقم السري غير صحيح!",
                "خطأ في الدخول",
                JOptionPane.ERROR_MESSAGE
            );

        }
    }
}
}