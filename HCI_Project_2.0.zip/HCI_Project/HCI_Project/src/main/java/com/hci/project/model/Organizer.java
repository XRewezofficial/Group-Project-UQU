package com.hci.project.model;
public class Organizer {
private final String organizerId;
private final String name;
private String password; // الرقم السري
private final String phone;
private final String campaignName;
private final String tentNumber;
private String specialRequest;


public Organizer(String organizerId, String name, String password, String phone, String campaignName, String tentNumber) {
    this.organizerId = organizerId;
    this.name = name;
    this.password = password;
    this.phone = phone;
    this.campaignName = campaignName;
    this.tentNumber = tentNumber;
    this.specialRequest = "لا يوجد";
}


// Getters and Setters
public String getOrganizerId() { return organizerId; }
public String getName() { return name; }
public String getPassword() { return password; }
public void setPassword(String password) { this.password = password; }
public String getPhone() { return phone; }
public String getCampaignName() { return campaignName; }
public String getTentNumber() { return tentNumber; }
public String getSpecialRequest() { return specialRequest; }
public void setSpecialRequest(String specialRequest) { this.specialRequest = specialRequest; }
}