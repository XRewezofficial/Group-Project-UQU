package com.hci.project.model;

public class Pilgrim {
    private String nationalId;
    private String name;
    private String password; // الرقم السري
    private String phone;
    private String busNumber;
    private String tentNumber;
    private String specialRequest;

    public Pilgrim(String nationalId, String name, String password, String phone, String busNumber, String tentNumber) {
        this.nationalId = nationalId;
        this.name = name;
        this.password = password;
        this.phone = phone;
        this.busNumber = busNumber;
        this.tentNumber = tentNumber;
        this.specialRequest = "لا يوجد";
    }

    // Getters and Setters
    public String getNationalId() { return nationalId; }
    public String getName() { return name; }
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
    public String getPhone() { return phone; }
    public String getBusNumber() { return busNumber; }
    public String getTentNumber() { return tentNumber; }
    public String getSpecialRequest() { return specialRequest; }
    public void setSpecialRequest(String specialRequest) { this.specialRequest = specialRequest; }
}