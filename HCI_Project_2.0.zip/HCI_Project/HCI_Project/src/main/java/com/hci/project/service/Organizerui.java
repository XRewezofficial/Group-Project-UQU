/*
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template */ package com.hci.project.service;
/** *
@author naf */
import com.hci.project.model.Organizer; import java.util.ArrayList;
public class Organizerui {
public static ArrayList<Organizer> organizersList = new ArrayList<>();


// بيانات تجريبية (رقم المنظم, الاسم, الرقم السري, الهاتف, اسم الحملة, رقم الخيمة)
static {

    organizersList.add(new Organizer("203249", "خالد عبدالله", "4321", "0501113333", "حملة النور", "T-10"));
    organizersList.add(new Organizer("207293", "محمد علي", "8765", "0504446666", "حملة الإيمان", "T-12"));
    organizersList.add(new Organizer("212944", "عبدالرحمن سعد", "2211", "0507779999", "حملة الخير", "T-15"));

}


// التحقق من المطابقة بين رقم المنظم وكلمة المرور
public static Organizer authenticateOrganizer(String organizerId, String password) {


    for (Organizer o : organizersList) {


        if (o.getOrganizerId().trim().equals(organizerId.trim()) && 
            o.getPassword().equals(password)) {


            return o; // تم التحقق بنجاح

        }

    }


    return null; // البيانات غير صحيحة

}
}