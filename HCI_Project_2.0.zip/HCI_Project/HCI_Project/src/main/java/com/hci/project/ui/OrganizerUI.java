/*
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template */ package com.hci.project.ui;
import javax.swing.JOptionPane; import com.hci.project.model.Organizer;
/* ~ @author s447004056 - Abdulaziz */
public class OrganizerUI {
public static void showOrganizerMenu(Organizer organizer) {
    boolean exit = false;

    while (!exit) {
        String[] options = {
            "عرض بطاقة المنظم",
            "جدول إدارة الحملة",
            "إدارة طلبات الحجاج",
            "إرسال بلاغ طوارئ",
            "تسجيل الخروج"
        };

        int choice = JOptionPane.showOptionDialog(
            null,
            "مرحباً بك يا " + organizer.getName() + "\nالرجاء اختيار الخدمة المطلوبة:",
            "بوابة منظم الحملة - نظام حجاج الداخل",
            JOptionPane.DEFAULT_OPTION,
            JOptionPane.INFORMATION_MESSAGE,
            null,
            options,
            options[0]
        );

        switch (choice) {
            case 0 -> showOrganizerCard(organizer);
            case 1 -> showSchedule();
            case 2 -> requestService(organizer);
            case 3 -> sendEmergencyAlert(organizer);
            case 4, -1 -> exit = true;
        }
    }
}

// 1. عرض بطاقة المنظم
private static void showOrganizerCard(Organizer organizer) {
    String cardInfo = """
                      === \u0628\u0637\u0627\u0642\u0629 \u0645\u0646\u0638\u0645 \u0627\u0644\u062d\u0645\u0644\u0629 ===
                      \u0627\u0644\u0627\u0633\u0645: """ + organizer.getName() + "\n"
            + "رقم المنظم: " + organizer.getOrganizerId() + "\n"
            + "رقم الهاتف: " + organizer.getPhone() + "\n"
            + "اسم الحملة: " + organizer.getCampaignName() + "\n"
            + "الطلبات الخاصة: " + organizer.getSpecialRequest();

    JOptionPane.showMessageDialog(null, cardInfo, "بطاقة المنظم", JOptionPane.INFORMATION_MESSAGE);
}

// 2. جدول إدارة الحملة
private static void showSchedule() {
    String schedule = """
                      === \u062c\u062f\u0648\u0644 \u0625\u062f\u0627\u0631\u0629 \u0627\u0644\u062d\u0645\u0644\u0629 ===
                      1. \u0645\u062a\u0627\u0628\u0639\u0629 \u062a\u062c\u0647\u064a\u0632 \u0627\u0644\u0645\u062e\u064a\u0645\u0627\u062a
                      2. \u062a\u0646\u0638\u064a\u0645 \u062d\u0631\u0643\u0629 \u0627\u0644\u062d\u062c\u0627\u062c
                      3. \u0645\u062a\u0627\u0628\u0639\u0629 \u0637\u0644\u0628\u0627\u062a \u0627\u0644\u062e\u062f\u0645\u0627\u062a
                      4. \u0627\u0644\u062a\u0648\u0627\u0635\u0644 \u0645\u0639 \u0625\u062f\u0627\u0631\u0629 \u0627\u0644\u0639\u0645\u0644\u064a\u0627\u062a""";

    JOptionPane.showMessageDialog(null, schedule, "جدول الإدارة", JOptionPane.PLAIN_MESSAGE);
}

// 3. تقديم طلب خدمة
private static void requestService(Organizer organizer) {
    String[] services = {
        "طلب دعم إضافي للحملة",
        "طلب تجهيزات للمخيم",
        "طلب مساعدة تنظيمية"
    };

    String selectedService = (String) JOptionPane.showInputDialog(
            null,
            "اختر نوع الطلب الذي تحتاجه:",
            "طلبات المنظم",
            JOptionPane.QUESTION_MESSAGE,
            null,
            services,
            services[0]
    );

    if (selectedService != null) {
        organizer.setSpecialRequest(selectedService);
        JOptionPane.showMessageDialog(null, "تم تسجيل طلبك بنجاح: " + selectedService, "نجاح", JOptionPane.INFORMATION_MESSAGE);
    }
}

// 4. بلاغ الطوارئ
private static void sendEmergencyAlert(Organizer organizer) {
    int confirm = JOptionPane.showConfirmDialog(
            null,
            "هل توجد حالة طوارئ داخل الحملة وتحتاج إلى تدخل؟",
            "تأكيد بلاغ الطوارئ",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE
    );

    if (confirm == JOptionPane.YES_OPTION) {
        JOptionPane.showMessageDialog(
                null,
                "تم إرسال نداء الطوارئ للحملة: " + organizer.getCampaignName(),
                "تم الإرسال",
                JOptionPane.ERROR_MESSAGE
        );
    }
}
}