/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.hci.project.ui;

import javax.swing.JOptionPane;
import com.hci.project.model.Pilgrim;

/*
 ~ @author s447004056 - Abdulaziz
 */

public class PilgrimUI {

    public static void showPilgrimMenu(Pilgrim pilgrim) {
        boolean exit = false;

        while (!exit) {
            String[] options = {
                "عرض البطاقة الرقمية",
                "جدول التفويض والتنقل",
                "تقديم طلب خدمة",
                "إرسال بلاغ طوارئ",
                "تسجيل الخروج"
            };

            int choice = JOptionPane.showOptionDialog(
                null,
                "مرحباً بك يا " + pilgrim.getName() + "\nالرجاء اختيار الخدمة المطلوبة:",
                "بوابة الحاج - نظام حجاج الداخل",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.INFORMATION_MESSAGE,
                null,
                options,
                options[0]
            );

            switch (choice) {
                case 0:
                    showDigitalCard(pilgrim);
                    break;
                case 1:
                    showSchedule();
                    break;
                case 2:
                    requestService(pilgrim);
                    break;
                case 3:
                    sendEmergencyAlert(pilgrim);
                    break;
                case 4:
                case -1: // في حال إغلاق النافذة
                    exit = true;
                    break;
            }
        }
    }

    // 1. عرض البطاقة الرقمية
    private static void showDigitalCard(Pilgrim pilgrim) {
        String cardInfo = "=== البطاقة الرقمية للحاج ===\n"
                + "الاسم: " + pilgrim.getName() + "\n"
                + "رقم الهوية: " + pilgrim.getNationalId() + "\n"
                + "رقم الحافلة: " + pilgrim.getBusNumber() + "\n"
                + "رقم الخيمة: " + pilgrim.getTentNumber() + "\n"
                + "الطلبات الخاصة: " + pilgrim.getSpecialRequest();

        JOptionPane.showMessageDialog(null, cardInfo, "بطاقة الحاج", JOptionPane.INFORMATION_MESSAGE);
    }

    // 2. جدول المواعيد والتفويض
    private static void showSchedule() {
        String schedule = "=== جدول التفويض للمشاعر المقدسة ===\n"
                + "1. التصعيد إلى عرفة: يوم 9 ذو الحجة - 06:00 صباحاً\n"
                + "2. النفرة إلى مزدلفة: يوم 9 ذو الحجة - 06:30 مساءً\n"
                + "3. رمي جمرة العقبة: يوم 10 ذو الحجة - 08:30 صباحاً\n"
                + "4. طواف الإفاضة: يوم 10 ذو الحجة - 04:00 عصراً";

        JOptionPane.showMessageDialog(null, schedule, "جدول المواعيد", JOptionPane.PLAIN_MESSAGE);
    }

    // 3. تقديم طلب خدمة
    private static void requestService(Pilgrim pilgrim) {
        String[] services = {"وجبة خاصة (سكري/حمية)", "طلب كرسي متحرك", "مساعدة في المفقودات"};
        
        String selectedService = (String) JOptionPane.showInputDialog(
                null,
                "اختر نوع الخدمة التي تحتاجهـا:",
                "طلب خدمة",
                JOptionPane.QUESTION_MESSAGE,
                null,
                services,
                services[0]
        );

        if (selectedService != null) {
            pilgrim.setSpecialRequest(selectedService);
            JOptionPane.showMessageDialog(null, "تم تسجيل طلبك بنجاح: " + selectedService, "نجاح", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    // 4. بلاغ الطوارئ
    private static void sendEmergencyAlert(Pilgrim pilgrim) {
        int confirm = JOptionPane.showConfirmDialog(
                null,
                "هل أنت أصلًا في حالة طوارئ وتدعو للمساعدة الميدانية؟",
                "تأكيد بلاغ الطوارئ",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE
        );

        if (confirm == JOptionPane.YES_OPTION) {
            JOptionPane.showMessageDialog(
                    null,
                    "تم إرسال نداء الاستغاثة لمدير العمليات والمنظمين القريبين من خيمتك (" + pilgrim.getTentNumber() + ").",
                    "تم الإرسال",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }
}